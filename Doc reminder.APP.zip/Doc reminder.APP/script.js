function showDoctorHome() {
  document.getElementById("mainContent").innerHTML = `
    <h2>Doctor Dashboard</h2>
    <div class="appointment-card">Upcoming Appointments will show here.</div>
    <div class="appointment-card">Patient List will show here.</div>
  `;
}

function showAddAppointment() {
  document.getElementById("mainContent").innerHTML = `
    <h2>Add New Appointment</h2>
    <form onsubmit="saveAppointment(event)">
      <input type="text" id="patientName" placeholder="Patient Name" required />
      <textarea id="illness" placeholder="Illness Description" required></textarea>
      <textarea id="treatment" placeholder="Cure Given / Notes" required></textarea>
      <input type="datetime-local" id="nextAppointment" required />
      <button type="submit">Save Appointment</button>
    </form>
  `;
}

function showPatientView() {
  document.getElementById("mainContent").innerHTML = `
    <h2>Patient View</h2>
    <div class="appointment-card">
      <strong>Next Appointment:</strong> <span id="apptTime">N/A</span><br>
      <strong>Doctor:</strong> <span id="doctorName">N/A</span><br>
      <strong>Notes:</strong> <span id="treatmentNotes">N/A</span>
    </div>
    <label><input type="checkbox" id="alertToggle" checked /> Alert Reminder</label>
  `;
}

function saveAppointment(event) {
  event.preventDefault();
  const name = document.getElementById("patientName").value;
  const illness = document.getElementById("illness").value;
  const treatment = document.getElementById("treatment").value;
  const nextAppt = document.getElementById("nextAppointment").value;

  alert(`Appointment for ${name} on ${nextAppt} saved.`);
  
  // You can add your saving logic here (e.g., localStorage, API call)

  showDoctorHome();
}

// Default view on page load
showDoctorHome();